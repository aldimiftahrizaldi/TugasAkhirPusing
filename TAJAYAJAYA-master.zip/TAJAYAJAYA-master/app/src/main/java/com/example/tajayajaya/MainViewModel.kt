package com.example.tajayajaya

class MainViewModel {
}