package com.example.tajayajaya

enum class SortType {

    DATE, RUNNING_TIME, AVG_SPEED, DISTANCE, CALORIES_BURNED
}