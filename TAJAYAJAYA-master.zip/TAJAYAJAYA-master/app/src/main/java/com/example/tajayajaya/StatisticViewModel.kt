package com.example.tajayajaya

class StatisticViewModel {
}